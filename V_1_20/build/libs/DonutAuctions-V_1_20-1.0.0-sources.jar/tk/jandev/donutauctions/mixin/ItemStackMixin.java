package tk.jandev.donutauctions.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import tk.jandev.donutauctions.DonutAuctions;
import tk.jandev.donutauctions.ItemCache;

import java.util.List;

@Mixin(class_1799.class)
@Environment(EnvType.CLIENT)
public abstract class ItemStackMixin {
    @Shadow public abstract int getCount();

    @Shadow public abstract boolean hasNbt();

    @Shadow public abstract int getMaxCount();

    @Inject(
            method = "getTooltip",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/nbt/NbtCompound;contains(Ljava/lang/String;I)Z",
                    shift = At.Shift.AFTER,
                    ordinal = 0
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    public void appendAfterLore(class_1657 player, class_1836 context, CallbackInfoReturnable<List<class_2561>> cir, @Local(ordinal = 0) List<class_2561> tooltip) {
        if (player == null) return;
        final DonutAuctions donutAuctions = DonutAuctions.getInstance();

        if (donutAuctions.shouldRenderFor(this)) {
            appendTooltip(tooltip);
        }
    }

    @Inject(
            method = "getTooltip",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/item/ItemStack;hasNbt()Z",
                    shift = At.Shift.AFTER,
                    ordinal = 0
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    public void appendAfterLoreNoNBT(class_1657 player, class_1836 context, CallbackInfoReturnable<List<class_2561>> cir, @Local(ordinal = 0) List<class_2561> tooltip) {
        if (player == null) return;
        if (this.hasNbt()) return; // we've already appended our component after lore was appended

        final DonutAuctions donutAuctions = DonutAuctions.getInstance();
        if (donutAuctions.shouldRenderFor(this)) {
            appendTooltip(tooltip);
        }
    }

    @Unique
    private void appendTooltip(List<class_2561> tooltip) {
        final DonutAuctions donutAuctions = DonutAuctions.getInstance();

        ItemCache.CacheResult cacheResult = donutAuctions.getItemCache().getPrice(this);
        int count = this.getCount();

        List<class_2561> messages = donutAuctions.getTextFor(cacheResult, count, this.getMaxCount());

        tooltip.addAll(messages);
    }
}
