package tk.jandev.donutauctions;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import tk.jandev.donutauctions.util.FormattingUtil;
import tk.jandev.donutauctions.util.WrappedStack;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import static tk.jandev.donutauctions.ItemCache.CacheResult.MONEY_COLOR;

public class DonutAuctions extends DonutAuctionsCommon<class_2561> implements ClientModInitializer {
    private final class_310 mc = class_310.method_1551();

    @Override
    public void onInitializeClient() {
        String dotMinecraft = class_310.method_1551().field_1697.getAbsolutePath();
        String fullPath = dotMinecraft + "/config/donutauctions";

        super.setup(fullPath);
    }

    @Override
    protected void registerGameMessageListener(Consumer<String> listener) {
        ClientReceiveMessageEvents.GAME.register((text, b) -> listener.accept(text.getString()));
    }

    @Override
    protected void sendPlayerMessage(String message) {
        mc.field_1724.method_43496(class_2561.method_43470(message));
    }

    @Override
    public WrappedStack createWrappedStack(Object nativeStack) {
        class_1799 itemStack = (class_1799) nativeStack;
        if (isShulkerBox(itemStack)) return wrapShulker(itemStack);

        String id = class_7923.field_41178.method_10221(itemStack.method_7909()).method_12832();
        int count = itemStack.method_7947();

        Map<String, Integer> enchants = new HashMap<>();

        for (var entry : class_1890.method_8222(itemStack).entrySet()) {
            class_1887 enchantment = entry.getKey();
            int level = entry.getValue();

            String enchantmentName = class_7923.field_41176.method_10221(enchantment).toString();

            enchants.put(enchantmentName, level);
        }

        return new WrappedStack(id, count, enchants, null);
    }

    @Override
    public boolean shouldRenderFor(Object nativeStack) {
        class_1799 stack = (class_1799) nativeStack;

        if (mc.field_1724 == null) return false;
        if (!isClientOnDonutSMP()) return false;
        if (mc.field_1724.method_31548().method_7379(stack)) return true;
        return mc.field_1724.field_7512.method_7602().contains(stack);
    }

    private WrappedStack wrapShulker(class_1799 shulkerStack) {
        class_2487 nbt = shulkerStack.method_7969();
        if (nbt == null || !nbt.method_10545("BlockEntityTag")) {
            return null;
        }
        List<class_1799> stacks = new ArrayList<>();

        class_2487 blockEntityTag = nbt.method_10562("BlockEntityTag");
        class_2499 itemsList = blockEntityTag.method_10554("Items", class_2520.field_33260);

        for (int i = 0; i < itemsList.size(); i++) {
            class_2487 itemTag = itemsList.method_10602(i);
            int slot = itemTag.method_10571("Slot") & 255;
            stacks.add(slot, class_1799.method_7915(itemTag));
        }

        return new WrappedStack(
                "minecraft:shulker_box",
                1, Map.of(),
                stacks.stream().map(this::createWrappedStack).toList()
        );
    }

    private boolean isShulkerBox(class_1799 itemStack) {
        class_2487 nbt = itemStack.method_7969();
        return nbt != null && nbt.method_10545("BlockEntityTag");
    }

    @Override
    protected boolean isClientOnDonutSMP() {
        return true;
    }

    @Override
    public List<class_2561> getTextFor(ItemCache.CacheResult cacheResult, int stackCount, int maxStackCount) {
        switch (cacheResult.status()) {
            case LOADING -> {
                return List.of(class_2561.method_43470("§7Loading.."));
            }
            case SUCCESS -> {
                List<class_2561> result = new ArrayList<>();
                double pricePerItem = cacheResult.priceData();

                long actualPrice = (long) pricePerItem * stackCount;
                long pricePerFullStack = (long) pricePerItem * maxStackCount;
                long pricePerShulker = pricePerFullStack * 27;

                class_2561 lineOne = class_2561.method_43470("§7Auction-Value: ")
                        .method_10852(class_2561.method_43470("$" + FormattingUtil.formatCurrency(actualPrice)).method_27694(style -> style.method_36139(MONEY_COLOR)));

                result.add(lineOne);

                if (shouldRenderSingularPrice()) {
                    class_2561 pricePerItemLine = class_2561.method_43470("§7Price Per Item: ").method_27693(FormattingUtil.formatCurrency((long) pricePerItem)).method_27694(style -> style.method_36139(MONEY_COLOR));
                    result.add(pricePerItemLine);
                }

                if (shouldRenderShulkerPrice()) {
                    class_2561 pricePerShulkerLine = class_2561.method_43470("§7Price Per Shulker: ").method_27693(FormattingUtil.formatCurrency(pricePerShulker)).method_27694(style -> style.method_36139(MONEY_COLOR));
                    result.add(pricePerShulkerLine);
                }

                return result;
            }
            case NO_API_KEY -> {
                return List.of(class_2561.method_43470("§cType /api to set your API-Key"));
            }
            case NO_RESULTS -> {
                return List.of(class_2561.method_43470("§7No Auctions Found"));
            }
        };
        return List.of();
    }
}
