package tk.jandev.donutauctions.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10712;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import tk.jandev.donutauctions.DonutAuctions;
import tk.jandev.donutauctions.ItemCache;

import java.util.List;
import java.util.function.Consumer;

@Mixin(class_1799.class)
@Environment(EnvType.CLIENT)
public abstract class ItemStackMixin {
    @Shadow public abstract int getCount();

    @Shadow public abstract int getMaxCount();

    @Inject(
            method = "Lnet/minecraft/item/ItemStack;appendTooltip(Lnet/minecraft/item/Item$TooltipContext;Lnet/minecraft/component/type/TooltipDisplayComponent;Lnet/minecraft/entity/player/PlayerEntity;Lnet/minecraft/item/tooltip/TooltipType;Ljava/util/function/Consumer;)V",
            at = @At(
                    value = "INVOKE", // inject into the place where LORE is applied!
                    target = "Lnet/minecraft/item/ItemStack;appendComponentTooltip(Lnet/minecraft/component/ComponentType;Lnet/minecraft/item/Item$TooltipContext;Lnet/minecraft/component/type/TooltipDisplayComponent;Ljava/util/function/Consumer;Lnet/minecraft/item/tooltip/TooltipType;)V",
                    shift = At.Shift.AFTER,
                    ordinal = 18
            )
    )
    public void appendAfterLore(class_1792.class_9635 context, class_10712 displayComponent, class_1657 player, class_1836 type, Consumer<class_2561> textConsumer, CallbackInfo ci) {
        if (player == null) return;
        final DonutAuctions donutAuctions = DonutAuctions.getInstance();

        if (donutAuctions.shouldRenderFor(this)) {
            appendTooltip(textConsumer);
        }
    }


    @Unique
    private void appendTooltip(Consumer<class_2561> consumer) {
        final DonutAuctions donutAuctions = DonutAuctions.getInstance();

        ItemCache.CacheResult cacheResult = donutAuctions.getItemCache().getPrice(this);
        int count = this.getCount();

        List<class_2561> messages = donutAuctions.getTextFor(cacheResult, count, this.getMaxCount());

        messages.forEach(consumer);
    }
}
